#include <bits/stdc++.h>
using namespace std ;

typedef struct packet {
	double start_time ;
	double end_time ;
    double current_time ;
	int packet_id ;
	int packet_source ;
	int type ;
} packet ;

typedef struct source {
	int source_id ;
	double source_to_switch_time ;
	double sending_rate ;
} source ;

double link_used_till[50] ;

typedef struct switchh {
	double last_arrived ;
	int arrived_from_source ;
} switchh ;

double last_arrived_at_sink = 0 ;
double switch_to_sink_time ;

struct Comparetime { 
    bool operator()(packet*  p1, packet* p2) 
    { return p1->current_time >= p2->current_time ; } 
} ; 

int main()
{
  int i, j, no_of_source ;
  for(i=0;i<50;i=i+1)
  { link_used_till[i] = 0 ; }
  cout << "Enter the number of sources: " ;
  cin >> no_of_source ; 
  source src[no_of_source] ;
  for(i=0;i<no_of_source;i=i+1)
  {
	src[i].source_id = i ;
	cout << "Enter the time to reach the switch from source-" << i+1 << ": " ;
	cin >> src[i].source_to_switch_time ;
  }
  cout << "Enter the time to reach the sink from the switch: " ;
  cin >> switch_to_sink_time ;
  double k ;
  for(k=10;k>=0.1;k=k-0.1)
  {	
  	for(i=0;i<no_of_source;i=i+1)
	{ src[i].sending_rate = k ; }
	priority_queue<packet*,vector<packet*>,Comparetime> Q ;
	packet pack[200000] ;
	int no_of_packets=0, tot_pack=0, maxx_allowed=200000/no_of_source ;
	for(i=0;i<no_of_source;i=i+1)
	{
		double time=0 ;
		tot_pack=0 ;
		for(time=0,tot_pack=0; time<1500 && tot_pack<maxx_allowed; time = time+src[i].sending_rate)
		{
			pack[no_of_packets].start_time = time ;
			pack[no_of_packets].end_time = 9999 ;
			pack[no_of_packets].current_time = time ;
			pack[no_of_packets].packet_id = no_of_packets ;
			pack[no_of_packets].packet_source = i ;
			pack[no_of_packets].type = 0 ;
			Q.push(pack + no_of_packets) ;
			no_of_packets = no_of_packets+1 ;
			tot_pack = tot_pack+1 ;
		}
	}
	while(!Q.empty())
	{
		packet* p = Q.top() ;
		Q.pop() ;
		if(p->type==0)
		{
			int from_source = p->packet_source ;
			if(p->start_time >= link_used_till[from_source])
			{
				p->current_time = p->start_time + src[from_source].source_to_switch_time ;
				p->type = 1 ;
				link_used_till[from_source] = p->current_time ;
				Q.push(p) ;
			}
			else if(p->start_time >= link_used_till[from_source] - src[from_source].source_to_switch_time)
			{
				p->current_time = link_used_till[from_source] + src[from_source].source_to_switch_time ;
				p->type = 1 ;
				link_used_till[from_source] = p->current_time ;
				Q.push(p) ;
			}
		} 	
		else if(p->type==1)
		{
			if(p->current_time >= last_arrived_at_sink)
			{
				p->end_time = p->current_time + switch_to_sink_time ;
				last_arrived_at_sink = p->end_time ;
				p->type = 2 ;
			}
			else if(p->current_time >= last_arrived_at_sink - switch_to_sink_time)
			{
				p->end_time = last_arrived_at_sink + switch_to_sink_time ;
				last_arrived_at_sink = p->end_time ;
				p->type = 2 ;
			}
		}
	}
	cout << "PACKET SENDING RATE" << " | "  << "AVG. DELAY" << endl ;
  	for(j=0;j<no_of_source;j=j+1)
	{
		double delay = 0 ;
		int total_packets = 0 ;
		for(i=0;i<no_of_packets;i=i+1)
		{	
		  if(j == pack[i].packet_source)
		  {		
		    delay = delay + (pack[i].end_time - pack[i].start_time) ; 
		    total_packets = total_packets + 1 ;
		  } 
		}
		cout << k << "	            | " << (delay/total_packets) << "\n" ;
	    delay=0 ; total_packets=0 ;   
	}
    last_arrived_at_sink = 0 ;
    for(i=0;i<50;i=i+1)
    { link_used_till[i] = 0 ; }
  }
  return 0 ;
}