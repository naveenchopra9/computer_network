import socket    # Import socket module
import thread
# from thread import *
def on_new_client(clientsocket,addr):
    while True:
        msg = clientsocket.recv(1024)
        #do some checks and if msg == someWeirdSignal: break:
        print(addr, ' >> ', msg)
        msg = raw_input('SERVER >> ')
        #Maybe some code to compute the last digit of PI, play game or anything else can go here and when you are done.
        clientsocket.send(msg)
    
    clientsocket.close()

serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)			 # Create a socket object


host = "172.16.129.162"		# Get local machine name
port = 8000			 # Reserve a port for your service.

print (host)
print (port)
print()
serversocket.bind((host, port))		# Bind to the port

serversocket.listen(5)	# Now wait for client connection.
# (clientsocket, address) = serversocket.accept()		 # Establish connection with client.
# c, addr = serversocket.accept() 
print ('server started and listening ')
while 1:
    # print ("connection found!")
    # data = clientsocket.recv(1024).decode()
    # print (data)
    # r=input("enter:")
    c, addr = serversocket.accept()
    thread.start_new_thread(on_new_client,(c,addr))
    # clientsocket.send(r.encode())

serversocket.close() 	 # Close the connection




















# import socket    # Import socket module

# serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)			 # Create a socket object

# host = "172.16.129.162"		# Get local machine name
# port = 8000			 # Reserve a port for your service.

# print (host)
# print (port)
# print()
# serversocket.bind((host, port))		# Bind to the port

# serversocket.listen(5)	# Now wait for client connection.
# (clientsocket, address) = serversocket.accept()		 # Establish connection with client.

# print ('server started and listening ')
# while 1:
#     print ("connection found!")
#     data = clientsocket.recv(1024).decode()
#     print (data)
#     r=input("enter:")
#     clientsocket.send(r.encode())

# serversocket.close() 	 # Close the connection