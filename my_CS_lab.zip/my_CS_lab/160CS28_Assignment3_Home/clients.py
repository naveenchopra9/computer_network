import socket  # Import socket module

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # Create a socket object
host ="172.16.129.162"	# Get local machine name
port =8000		 # Reserve a port for your service.
s.connect((host,port))	# Bind to the port
	
def ts(r):
   s.send(r.encode()) 
   data = ''
   data = s.recv(1024).decode()
   print (data)

while 1:
   r = input('enter : ')
   ts(r)

s.close ()	 # Close the connection

	