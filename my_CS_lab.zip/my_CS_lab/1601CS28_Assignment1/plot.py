import matplotlib.pyplot as plt
import numpy as np

x,y = np.loadtxt('/Users/naveen/Documents/online_code/output.txt', delimiter=' ', unpack=True)

plt.plot(x,y, label='sending rate vs average time delay')
plt.xlabel('Number of pages')
plt.ylabel('Hits')
plt.title('LFU_hits')
plt.show()

