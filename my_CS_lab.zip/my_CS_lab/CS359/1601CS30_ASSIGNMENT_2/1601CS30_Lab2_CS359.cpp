#include<bits/stdc++.h>
#include <random>
using namespace std;
/*
execute as g++ <filename>.cpp -std=c++11
*/
typedef struct packet {
    double start_time ;
    double end_time ;
    double current_time ;
    int packet_id ;
    int packet_source ;
    int type ;
} packet ;

typedef struct source {
    int source_id ;
    double source_to_switch_time ;
    double sending_rate ;
} source ;

double link_used_till[50] ;

typedef struct switchh {
    double last_arrived ;
    int arrived_from_source ;
} switchh ;

double last_arrived_at_sink = 0 ;
double switch_to_sink_time ;

struct Comparetime { 
    bool operator()(packet*  p1, packet* p2) 
    { return p1->current_time >= p2->current_time ; } 
} ;

double getgenerator(double sending_rate) {
    default_random_engine generator ;
    uniform_real_distribution <double> distribution(0.0,1.0) ;
    double number=0.0 ;
    number = distribution(generator) ;
    double t = (-1.0)*(log(1-number)/sending_rate) ;
    return t ;
}

int main()
{
  int i, j, k, no_of_source ; 
  cout << "Enter the number of sources: " ;
  cin >> no_of_source ;
  source src[no_of_source] ;
  for(i=0;i<no_of_source;i=i+1)
  {
    src[i].source_id = i ;
    cout << "Enter the time to reach the switch from source-" << i+1 << ": " ;
    cin >> src[i].source_to_switch_time ;
  }
  cout << "Enter the time to reach the sink from the switch: " ;
  cin >> switch_to_sink_time ;    
  double maxai, nid=0 ;
  cout << "Max value for ai : " ;
  cin >> maxai ;
  default_random_engine generator ; 
  uniform_real_distribution <double> distribution(0.0,1.0) ;
  while(nid<maxai) 
  {
    last_arrived_at_sink=0 ;
    nid = nid + 0.05 ;
    priority_queue<packet*,vector<packet*>,Comparetime> Q ;
    packet pck[200000] ;
    for(i=0;i<50;i++)
    { link_used_till[i]=0 ; }
    int maxx_allowed=200000/no_of_source, no_of_packets=0;
    for(i=0;i<no_of_source;i++)
    {
        int tot_pck ;
        double number=distribution(generator) ;
        double t = (-1.0)*(log(1-number)/(nid)) ;
        double temp=0.0 ;
        for(tot_pck=0;tot_pck<100;tot_pck=tot_pck+1)
        {
            temp = temp+t ;
            pck[no_of_packets].start_time = temp ;
            pck[no_of_packets].end_time = 9999 ;
            pck[no_of_packets].current_time = temp ;
            pck[no_of_packets].packet_id = no_of_packets ;
            pck[no_of_packets].packet_source = i ; 
            pck[no_of_packets].type = 0 ;
            Q.push(pck+no_of_packets) ;
            no_of_packets = no_of_packets+1 ;
        }
    }
    while(!Q.empty())
    {
        packet* p=Q.top() ;
        Q.pop() ;
        if(p->type==0)
        {
            int from_source=p->packet_source;
            if(p->start_time >= link_used_till[from_source])
            {
                p->current_time = p->start_time + src[from_source].source_to_switch_time ;
                p->type=1 ;
                link_used_till[from_source] = p->current_time ;
                Q.push(p) ;
            }
            else if(p->start_time >= link_used_till[from_source] - src[from_source].source_to_switch_time)
            {
                p->current_time = link_used_till[from_source] + src[from_source].source_to_switch_time;
                p->type=1 ;
                link_used_till[from_source] = p->current_time ;
                Q.push(p) ;
            }
        }
        else if(p->type==1)
        {
            if(p->current_time >= last_arrived_at_sink)
            {
                p->end_time = p->current_time + switch_to_sink_time ;
                last_arrived_at_sink = p->end_time ;
                p->type=2 ;
            }
            else if(p->current_time >= last_arrived_at_sink - switch_to_sink_time)
            {
                p->end_time = last_arrived_at_sink + switch_to_sink_time ;
                last_arrived_at_sink = p->end_time ;
                p->type=2 ;
            }
        }
    }
    double dlay=0 ;
    double delay[no_of_source] ;
    int count[no_of_source] ;
    for(i=0;i<no_of_source;i=i+1)
    { delay[i]=0.0 ; count[i]=0 ; }
    int total_packets=0;
    for(i=0;i<no_of_packets;i=i+1)
    {
        count[pck[i].packet_source] = count[pck[i].packet_source]+1 ;
        delay[pck[i].packet_source] = delay[pck[i].packet_source] + (pck[i].end_time-pck[i].start_time);
        dlay = dlay + (pck[i].end_time-pck[i].start_time) ;
        total_packets = total_packets+1 ;
    }
    for(i=0;i<no_of_source;i=i+1)
    { cout << delay[i]/count[i] << "    | " ; }
    cout << nid << endl ;
  }
  return 0;
}