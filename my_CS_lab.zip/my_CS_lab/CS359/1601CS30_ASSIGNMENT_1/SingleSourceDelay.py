import matplotlib.pyplot as plt
x=[1/5,1/4,1/3,1/2,1/1,1/0.5,1/0.1,1/0.05,1/0.02,1/.01]
y=[8,8,2301.27,4617.18,6933.09,8091.04,9017.37,9133.18,9202.67,9225.84]
plt.plot(x, y, color='green', linestyle='dashed', linewidth = 3, 
         marker='o', markerfacecolor='blue', markersize=12)
plt.xlabel('Packet Sending Rates') 
plt.ylabel('Average Delay') 
plt.title('Single-source Delay') 
plt.show()